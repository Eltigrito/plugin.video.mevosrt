import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')

class MevoPlayer:
    def __init__(self):
        self.cam1_url = ADDON.getSetting("camera1_url")
        self.cam2_url = ADDON.getSetting("camera2_url")

    def play_split_screen(self):
        # Crea un diálogo personalizado con 2 reproductores
        dialog = xbmcgui.Dialog()
        dialog.textviewer(
            "Mevo Dual View", 
            f"Cámara 1: {self.cam1_url}\nCámara 2: {self.cam2_url}"
        )
        # Lógica avanzada para multivisión (requiere Kodi Matrix+)
        xbmc.executebuiltin(f"PlayWith({self.cam1_url})")
        xbmc.sleep(2000)  # Espera 2 segundos
        xbmc.executebuiltin(f"PlayerControl(PictureInPicture, {self.cam2_url})")

if __name__ == '__main__':
    player = MevoPlayer()
    player.play_split_screen()